"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Mic, MicOff, Video, VideoOff, PhoneOff } from "lucide-react"

interface VideoChatProps {
  roomName: string
  token: string
  onEnd: () => void
}

export function VideoChat({ roomName, token, onEnd }: VideoChatProps) {
  const [isMicMuted, setIsMicMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)

  // この部分は実際のTwilio Video SDKを使用する際に実装します
  // 以下はデモ用の簡易的な実装です

  useEffect(() => {
    // 実際の実装では、ここでTwilio Video SDKを初期化し、
    // ルームに接続する処理を行います

    const initializeVideoChat = async () => {
      try {
        // デモ用のタイマー - 実際の実装では削除します
        setTimeout(() => {
          setIsConnected(true)

          // ローカルビデオのデモ表示
          if (localVideoRef.current) {
            navigator.mediaDevices
              .getUserMedia({ video: true, audio: true })
              .then((stream) => {
                if (localVideoRef.current) {
                  localVideoRef.current.srcObject = stream
                }
              })
              .catch((err) => {
                setError("カメラまたはマイクへのアクセスが拒否されました")
              })
          }
        }, 1000)
      } catch (err) {
        setError("ビデオチャットの初期化中にエラーが発生しました")
      }
    }

    initializeVideoChat()

    // クリーンアップ関数
    return () => {
      // 実際の実装では、ここでTwilioのルームから切断する処理を行います
      if (localVideoRef.current && localVideoRef.current.srcObject) {
        const stream = localVideoRef.current.srcObject as MediaStream
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [roomName, token])

  const toggleMic = () => {
    setIsMicMuted(!isMicMuted)
    // 実際の実装では、ここでマイクのトラックを有効/無効にする処理を行います
  }

  const toggleVideo = () => {
    setIsVideoOff(!isVideoOff)
    // 実際の実装では、ここでビデオのトラックを有効/無効にする処理を行います
  }

  const endCall = () => {
    // 実際の実装では、ここでルームから切断する処理を行います
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream
      stream.getTracks().forEach((track) => track.stop())
    }
    onEnd()
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>オンライン診療 - {roomName}</span>
          <span
            className={`text-sm px-2 py-1 rounded ${isConnected ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"}`}
          >
            {isConnected ? "接続中" : "接続中..."}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {error ? (
          <div className="bg-red-50 text-red-700 p-4 rounded-md mb-4">{error}</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${isVideoOff ? "hidden" : ""}`}
              />
              {isVideoOff && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
                  <span className="text-gray-500">カメラオフ</span>
                </div>
              )}
              <div className="absolute bottom-2 left-2 bg-gray-800 text-white text-xs px-2 py-1 rounded">あなた</div>
            </div>

            <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
              <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-gray-500">相手が接続するのを待っています...</span>
              </div>
              <div className="absolute bottom-2 left-2 bg-gray-800 text-white text-xs px-2 py-1 rounded">医師</div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-center space-x-4">
        <Button
          variant={isMicMuted ? "outline" : "default"}
          size="icon"
          onClick={toggleMic}
          className="rounded-full h-12 w-12"
        >
          {isMicMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
        </Button>
        <Button
          variant={isVideoOff ? "outline" : "default"}
          size="icon"
          onClick={toggleVideo}
          className="rounded-full h-12 w-12"
        >
          {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
        </Button>
        <Button variant="destructive" size="icon" onClick={endCall} className="rounded-full h-12 w-12">
          <PhoneOff className="h-5 w-5" />
        </Button>
      </CardFooter>
    </Card>
  )
}
