"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Mic, MicOff, Video, VideoOff, PhoneOff } from "lucide-react"

interface SimpleVideoChatProps {
  onEnd?: () => void
}

export default function SimpleVideoChat({ onEnd }: SimpleVideoChatProps) {
  const [isMicMuted, setIsMicMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)

  // コンポーネントがマウントされたときにカメラとマイクにアクセス
  useEffect(() => {
    const startVideo = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = mediaStream
        }
        setStream(mediaStream)
      } catch (err) {
        console.error("カメラまたはマイクへのアクセスが拒否されました:", err)
      }
    }

    startVideo()

    // クリーンアップ関数
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  // マイクのミュート/ミュート解除
  const toggleMic = () => {
    if (stream) {
      const audioTracks = stream.getAudioTracks()
      audioTracks.forEach((track) => {
        track.enabled = isMicMuted
      })
      setIsMicMuted(!isMicMuted)
    }
  }

  // ビデオのオン/オフ
  const toggleVideo = () => {
    if (stream) {
      const videoTracks = stream.getVideoTracks()
      videoTracks.forEach((track) => {
        track.enabled = isVideoOff
      })
      setIsVideoOff(!isVideoOff)
    }
  }

  // 通話終了
  const endCall = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
    }
    if (onEnd) {
      onEnd()
    }
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>シンプルビデオチャット</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${isVideoOff ? "hidden" : ""}`}
            />
            {isVideoOff && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
                <span className="text-gray-500">カメラオフ</span>
              </div>
            )}
            <div className="absolute bottom-2 left-2 bg-gray-800 text-white text-xs px-2 py-1 rounded">あなた</div>
          </div>

          <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-gray-500">相手が接続するのを待っています...</span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-center space-x-4">
        <Button
          variant={isMicMuted ? "outline" : "default"}
          size="icon"
          onClick={toggleMic}
          className="rounded-full h-12 w-12"
        >
          {isMicMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
        </Button>
        <Button
          variant={isVideoOff ? "outline" : "default"}
          size="icon"
          onClick={toggleVideo}
          className="rounded-full h-12 w-12"
        >
          {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
        </Button>
        <Button variant="destructive" size="icon" onClick={endCall} className="rounded-full h-12 w-12">
          <PhoneOff className="h-5 w-5" />
        </Button>
      </CardFooter>
    </Card>
  )
}
