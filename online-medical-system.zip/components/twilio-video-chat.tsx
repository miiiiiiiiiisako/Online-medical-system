"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Mic, MicOff, Video, VideoOff, PhoneOff, Settings, Users } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface TwilioVideoChatProps {
  roomName: string
  token: string
  userName: string
  onEnd: () => void
}

export function TwilioVideoChat({ roomName, token, userName, onEnd }: TwilioVideoChatProps) {
  const [isMicMuted, setIsMicMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [participants, setParticipants] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [availableDevices, setAvailableDevices] = useState({
    audioInputs: [] as MediaDeviceInfo[],
    videoInputs: [] as MediaDeviceInfo[],
    audioOutputs: [] as MediaDeviceInfo[],
  })
  const [selectedDevices, setSelectedDevices] = useState({
    audioInput: "",
    videoInput: "",
    audioOutput: "",
  })

  const { toast } = useToast()
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRefs = useRef<{ [key: string]: HTMLVideoElement }>({})
  const roomRef = useRef<any>(null)
  const localTrackRefs = useRef<any[]>([])

  useEffect(() => {
    // Twilioのビデオライブラリをロード
    const loadTwilioVideo = async () => {
      try {
        // 実際の実装では、以下のようにTwilioビデオライブラリをインポートします
        // const Video = await import('twilio-video');

        // デモ用のモック実装
        console.log("Twilio Video SDKをロードしました")

        // 利用可能なデバイスを取得
        await getAvailableDevices()

        // ルームに接続
        connectToRoom()
      } catch (err) {
        console.error("Twilioビデオの読み込みエラー:", err)
        setError("ビデオチャットの初期化中にエラーが発生しました")
      }
    }

    loadTwilioVideo()

    // クリーンアップ関数
    return () => {
      // ルームから切断
      if (roomRef.current) {
        roomRef.current.disconnect()
      }

      // ローカルトラックを停止
      if (localTrackRefs.current) {
        localTrackRefs.current.forEach((track) => {
          if (track.stop) {
            track.stop()
          }
          if (track.detach) {
            track.detach().forEach((element: HTMLMediaElement) => element.remove())
          }
        })
      }
    }
  }, [token, roomName])

  const getAvailableDevices = async () => {
    try {
      // メディアデバイスへのアクセス許可を取得
      await navigator.mediaDevices.getUserMedia({ audio: true, video: true })

      // 利用可能なデバイスを列挙
      const devices = await navigator.mediaDevices.enumerateDevices()

      const audioInputs = devices.filter((device) => device.kind === "audioinput")
      const videoInputs = devices.filter((device) => device.kind === "videoinput")
      const audioOutputs = devices.filter((device) => device.kind === "audiooutput")

      setAvailableDevices({
        audioInputs,
        videoInputs,
        audioOutputs,
      })

      // デフォルトデバイスを選択
      if (audioInputs.length > 0) {
        setSelectedDevices((prev) => ({ ...prev, audioInput: audioInputs[0].deviceId }))
      }
      if (videoInputs.length > 0) {
        setSelectedDevices((prev) => ({ ...prev, videoInput: videoInputs[0].deviceId }))
      }
      if (audioOutputs.length > 0) {
        setSelectedDevices((prev) => ({ ...prev, audioOutput: audioOutputs[0].deviceId }))
      }
    } catch (err) {
      console.error("デバイス列挙エラー:", err)
      setError("カメラとマイクへのアクセスが拒否されました")
    }
  }

  const connectToRoom = async () => {
    try {
      // 実際の実装では、以下のようにTwilioルームに接続します
      /*
      const localTracks = await Video.createLocalTracks({
        audio: { deviceId: selectedDevices.audioInput || undefined },
        video: { deviceId: selectedDevices.videoInput || undefined }
      });
      
      localTrackRefs.current = localTracks;
      
      // ローカルビデオをプレビュー
      const videoTrack = localTracks.find(track => track.kind === 'video');
      if (videoTrack) {
        const videoElement = videoTrack.attach();
        localVideoRef.current.appendChild(videoElement);
      }
      
      // ルームに接続
      const room = await Video.connect(token, {
        name: roomName,
        tracks: localTracks,
        dominantSpeaker: true
      });
      
      roomRef.current = room;
      setIsConnected(true);
      
      // 既存の参加者を処理
      room.participants.forEach(participant => {
        handleParticipantConnected(participant);
      });
      
      // 新しい参加者が接続したときのイベント
      room.on('participantConnected', handleParticipantConnected);
      
      // 参加者が切断したときのイベント
      room.on('participantDisconnected', handleParticipantDisconnected);
      
      // ルームから切断したときのイベント
      room.on('disconnected', handleRoomDisconnected);
      */

      // デモ用のモック実装
      setTimeout(() => {
        setIsConnected(true)

        // ローカルビデオのデモ表示
        if (localVideoRef.current) {
          navigator.mediaDevices
            .getUserMedia({
              video: { deviceId: selectedDevices.videoInput || undefined },
              audio: { deviceId: selectedDevices.audioInput || undefined },
            })
            .then((stream) => {
              if (localVideoRef.current) {
                localVideoRef.current.srcObject = stream
              }
            })
            .catch((err) => {
              setError("カメラまたはマイクへのアクセスが拒否されました")
            })
        }

        // 模擬参加者を追加
        setParticipants([{ sid: "PA123", identity: "医師" }])

        toast({
          title: "ルームに接続しました",
          description: "ビデオチャットが開始されました",
        })
      }, 1500)
    } catch (err) {
      console.error("ルーム接続エラー:", err)
      setError("ビデオチャットルームへの接続に失敗しました")
    }
  }

  const handleParticipantConnected = (participant: any) => {
    // 参加者が接続したときの処理
    setParticipants((prev) => [...prev, participant])

    // 参加者のトラックを処理
    /*
    participant.tracks.forEach(publication => {
      if (publication.isSubscribed) {
        handleTrackSubscribed(participant, publication.track);
      }
    });
    
    participant.on('trackSubscribed', track => {
      handleTrackSubscribed(participant, track);
    });
    */
  }

  const handleParticipantDisconnected = (participant: any) => {
    // 参加者が切断したときの処理
    setParticipants((prev) => prev.filter((p) => p.sid !== participant.sid))
  }

  const handleTrackSubscribed = (participant: any, track: any) => {
    // 参加者のトラックを表示
    /*
    if (track.kind === 'video') {
      const videoElement = track.attach();
      if (remoteVideoRefs.current[participant.sid]) {
        remoteVideoRefs.current[participant.sid].appendChild(videoElement);
      }
    }
    */
  }

  const handleRoomDisconnected = () => {
    // ルームから切断したときの処理
    setIsConnected(false)
    setParticipants([])
  }

  const toggleMic = () => {
    setIsMicMuted(!isMicMuted)

    // 実際の実装では、以下のようにマイクをミュートします
    /*
    const audioTrack = localTrackRefs.current.find(track => track.kind === 'audio');
    if (audioTrack) {
      if (isMicMuted) {
        audioTrack.enable();
      } else {
        audioTrack.disable();
      }
    }
    */
  }

  const toggleVideo = () => {
    setIsVideoOff(!isVideoOff)

    // 実際の実装では、以下のようにビデオをオン/オフします
    /*
    const videoTrack = localTrackRefs.current.find(track => track.kind === 'video');
    if (videoTrack) {
      if (isVideoOff) {
        videoTrack.enable();
      } else {
        videoTrack.disable();
      }
    }
    */

    // デモ用の実装
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream
      const videoTracks = stream.getVideoTracks()
      videoTracks.forEach((track) => {
        track.enabled = isVideoOff
      })
    }
  }

  const changeDevice = async (type: "audioInput" | "videoInput" | "audioOutput", deviceId: string) => {
    setSelectedDevices((prev) => ({ ...prev, [type]: deviceId }))

    // 実際の実装では、デバイスを切り替えます
    /*
    if (roomRef.current) {
      // 既存のトラックを停止
      const tracksToStop = localTrackRefs.current.filter(track => 
        (type === 'audioInput' && track.kind === 'audio') ||
        (type === 'videoInput' && track.kind === 'video')
      );
      
      tracksToStop.forEach(track => {
        track.stop();
        roomRef.current.localParticipant.unpublishTrack(track);
      });
      
      // 新しいトラックを作成
      let newTrackOptions = {};
      if (type === 'audioInput') {
        newTrackOptions = { audio: { deviceId: { exact: deviceId } } };
      } else if (type === 'videoInput') {
        newTrackOptions = { video: { deviceId: { exact: deviceId } } };
      }
      
      const newTracks = await Video.createLocalTracks(newTrackOptions);
      
      // 新しいトラックをルームに公開
      newTracks.forEach(track => {
        roomRef.current.localParticipant.publishTrack(track);
      });
      
      // ローカルトラック参照を更新
      localTrackRefs.current = localTrackRefs.current
        .filter(track => !tracksToStop.includes(track))
        .concat(newTracks);
    }
    */

    // デモ用の実装
    if (type === "audioOutput" && localVideoRef.current && "setSinkId" in localVideoRef.current) {
      try {
        // @ts-ignore - TypeScriptはHTMLMediaElement.setSinkIdを認識しない場合があります
        await localVideoRef.current.setSinkId(deviceId)
        toast({
          title: "スピーカーを変更しました",
          description: "オーディオ出力デバイスが更新されました",
        })
      } catch (err) {
        console.error("スピーカー変更エラー:", err)
      }
    } else if ((type === "audioInput" || type === "videoInput") && localVideoRef.current) {
      try {
        const constraints: MediaStreamConstraints = {}
        if (type === "audioInput") {
          constraints.audio = { deviceId: { exact: deviceId } }
        } else {
          constraints.video = { deviceId: { exact: deviceId } }
        }

        const stream = await navigator.mediaDevices.getUserMedia(constraints)

        if (localVideoRef.current.srcObject) {
          const currentStream = localVideoRef.current.srcObject as MediaStream
          const currentTracks = type === "audioInput" ? currentStream.getAudioTracks() : currentStream.getVideoTracks()

          currentTracks.forEach((track) => track.stop())

          const newTracks = type === "audioInput" ? stream.getAudioTracks() : stream.getVideoTracks()

          newTracks.forEach((track) => {
            ;(localVideoRef.current!.srcObject as MediaStream).addTrack(track)
          })
        }

        toast({
          title: type === "audioInput" ? "マイクを変更しました" : "カメラを変更しました",
          description: "デバイスが更新されました",
        })
      } catch (err) {
        console.error("デバイス変更エラー:", err)
      }
    }
  }

  const endCall = () => {
    // ルームから切断
    if (roomRef.current) {
      roomRef.current.disconnect()
    }

    // ローカルトラックを停止
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream
      stream.getTracks().forEach((track) => track.stop())
    }

    toast({
      title: "通話終了",
      description: "ビデオチャットを終了しました",
    })

    onEnd()
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>オンライン診療 - {roomName}</span>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1"
              onClick={() => setIsSettingsOpen(!isSettingsOpen)}
            >
              <Settings className="h-4 w-4" />
              <span>設定</span>
            </Button>
            <span
              className={`text-sm px-2 py-1 rounded ${
                isConnected ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"
              }`}
            >
              {isConnected ? "接続中" : "接続中..."}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {error ? (
          <div className="bg-red-50 text-red-700 p-4 rounded-md mb-4">{error}</div>
        ) : (
          <>
            {isSettingsOpen && (
              <div className="bg-muted p-4 rounded-md mb-4">
                <h3 className="font-medium mb-2">デバイス設定</h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium block mb-1">マイク</label>
                    <select
                      className="w-full p-2 rounded-md border"
                      value={selectedDevices.audioInput}
                      onChange={(e) => changeDevice("audioInput", e.target.value)}
                    >
                      {availableDevices.audioInputs.map((device) => (
                        <option key={device.deviceId} value={device.deviceId}>
                          {device.label || `マイク ${availableDevices.audioInputs.indexOf(device) + 1}`}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium block mb-1">カメラ</label>
                    <select
                      className="w-full p-2 rounded-md border"
                      value={selectedDevices.videoInput}
                      onChange={(e) => changeDevice("videoInput", e.target.value)}
                    >
                      {availableDevices.videoInputs.map((device) => (
                        <option key={device.deviceId} value={device.deviceId}>
                          {device.label || `カメラ ${availableDevices.videoInputs.indexOf(device) + 1}`}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium block mb-1">スピーカー</label>
                    <select
                      className="w-full p-2 rounded-md border"
                      value={selectedDevices.audioOutput}
                      onChange={(e) => changeDevice("audioOutput", e.target.value)}
                    >
                      {availableDevices.audioOutputs.map((device) => (
                        <option key={device.deviceId} value={device.deviceId}>
                          {device.label || `スピーカー ${availableDevices.audioOutputs.indexOf(device) + 1}`}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${isVideoOff ? "hidden" : ""}`}
                />
                {isVideoOff && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
                    <span className="text-gray-500">カメラオフ</span>
                  </div>
                )}
                <div className="absolute bottom-2 left-2 bg-gray-800 text-white text-xs px-2 py-1 rounded">
                  {userName} (あなた) {isMicMuted && <MicOff className="h-3 w-3 inline ml-1" />}
                </div>
              </div>

              {participants.length > 0 ? (
                participants.map((participant) => (
                  <div key={participant.sid} className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
                    <div
                      ref={(el) => {
                        if (el) remoteVideoRefs.current[participant.sid] = el
                      }}
                      className="w-full h-full"
                    >
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-gray-500">ビデオ読み込み中...</span>
                      </div>
                    </div>
                    <div className="absolute bottom-2 left-2 bg-gray-800 text-white text-xs px-2 py-1 rounded">
                      {participant.identity}
                    </div>
                  </div>
                ))
              ) : (
                <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-gray-500">相手が接続するのを待っています...</span>
                  </div>
                </div>
              )}
            </div>

            {participants.length > 0 && (
              <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-md">
                <Users className="h-5 w-5 text-blue-500" />
                <div>
                  <span className="text-sm font-medium text-blue-700">参加者: {participants.length + 1}人</span>
                  <p className="text-xs text-blue-600">あなた, {participants.map((p) => p.identity).join(", ")}</p>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
      <CardFooter className="flex justify-center space-x-4">
        <Button
          variant={isMicMuted ? "outline" : "default"}
          size="icon"
          onClick={toggleMic}
          className="rounded-full h-12 w-12"
          disabled={!isConnected}
        >
          {isMicMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
        </Button>
        <Button
          variant={isVideoOff ? "outline" : "default"}
          size="icon"
          onClick={toggleVideo}
          className="rounded-full h-12 w-12"
          disabled={!isConnected}
        >
          {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
        </Button>
        <Button
          variant="destructive"
          size="icon"
          onClick={endCall}
          className="rounded-full h-12 w-12"
          disabled={!isConnected}
        >
          <PhoneOff className="h-5 w-5" />
        </Button>
      </CardFooter>
    </Card>
  )
}
