"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Globe } from "lucide-react"

type Language = {
  code: string
  name: string
  nativeName: string
}

const languages: Language[] = [
  { code: "ja", name: "Japanese", nativeName: "日本語" },
  { code: "en", name: "English", nativeName: "English" },
  { code: "zh", name: "Chinese", nativeName: "中文" },
]

export function LanguageSwitcher() {
  const [currentLang, setCurrentLang] = useState<string>("ja")

  useEffect(() => {
    // Get language from localStorage or default to Japanese
    const savedLang = localStorage.getItem("language") || "ja"
    setCurrentLang(savedLang)
    document.documentElement.lang = savedLang
  }, [])

  const changeLanguage = (langCode: string) => {
    setCurrentLang(langCode)
    localStorage.setItem("language", langCode)
    document.documentElement.lang = langCode
    // In a real app, you would also change the displayed text based on the selected language
    // This would typically be done with a translation library like next-intl or i18next
  }

  const getCurrentLanguageName = () => {
    const lang = languages.find((l) => l.code === currentLang)
    return lang ? lang.nativeName : "日本語"
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="h-9 gap-1">
          <Globe className="h-4 w-4" />
          <span>{getCurrentLanguageName()}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {languages.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => changeLanguage(lang.code)}
            className={currentLang === lang.code ? "bg-muted" : ""}
          >
            {lang.nativeName}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
