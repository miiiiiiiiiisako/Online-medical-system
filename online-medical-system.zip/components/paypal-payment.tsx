"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PayPalButtons } from "@paypal/react-paypal-js"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

interface PayPalPaymentProps {
  amount: number
  currency?: string
  description: string
  orderId?: string
  onSuccess: (details: any) => void
  onCancel?: () => void
  onError?: (error: any) => void
}

export function PayPalPayment({
  amount,
  currency = "JPY",
  description,
  orderId,
  onSuccess,
  onCancel,
  onError,
}: PayPalPaymentProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  // 金額を小数点以下2桁の文字列に変換（PayPal要件）
  const formattedAmount = amount.toFixed(2)

  const createOrder = (data: any, actions: any) => {
    return actions.order.create({
      purchase_units: [
        {
          description,
          amount: {
            currency_code: currency,
            value: formattedAmount,
          },
          reference_id: orderId || `order-${Date.now()}`,
        },
      ],
      application_context: {
        shipping_preference: "NO_SHIPPING", // 配送先住所の入力をスキップ
      },
    })
  }

  const onApprove = async (data: any, actions: any) => {
    setIsProcessing(true)
    try {
      // 支払いを完了
      const details = await actions.order.capture()

      // サーバーに支払い情報を送信
      const response = await fetch("/api/process-payment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId: data.orderID,
          paymentId: details.id,
          paymentDetails: details,
          amount: formattedAmount,
          currency,
          description,
        }),
      })

      if (!response.ok) {
        throw new Error("支払い処理の確認に失敗しました")
      }

      toast({
        title: "支払い完了",
        description: "支払いが正常に処理されました",
      })

      onSuccess(details)
    } catch (error) {
      console.error("Payment processing error:", error)
      toast({
        title: "支払いエラー",
        description: "支払い処理中にエラーが発生しました",
        variant: "destructive",
      })
      if (onError) onError(error)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleError = (err: any) => {
    console.error("PayPal error:", err)
    toast({
      title: "支払いエラー",
      description: "PayPalでエラーが発生しました",
      variant: "destructive",
    })
    if (onError) onError(err)
  }

  const handleCancel = () => {
    toast({
      title: "支払いキャンセル",
      description: "支払いがキャンセルされました",
    })
    if (onCancel) onCancel()
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>PayPalで支払う</CardTitle>
        <CardDescription>安全なオンライン支払い</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="border-b pb-4">
          <div className="flex justify-between mb-2">
            <span>{description}</span>
            <span>
              {currency} {formattedAmount}
            </span>
          </div>
          <div className="flex justify-between font-bold">
            <span>合計</span>
            <span>
              {currency} {formattedAmount}
            </span>
          </div>
        </div>

        {isProcessing ? (
          <div className="flex justify-center items-center py-6">
            <Loader2 className="h-8 w-8 animate-spin text-primary mr-2" />
            <span>処理中...</span>
          </div>
        ) : (
          <PayPalButtons
            style={{
              layout: "vertical",
              color: "blue",
              shape: "rect",
              label: "pay",
            }}
            createOrder={createOrder}
            onApprove={onApprove}
            onError={handleError}
            onCancel={handleCancel}
          />
        )}
      </CardContent>
      <CardFooter>
        <p className="text-xs text-muted-foreground">
          PayPalで支払うことで、当院の利用規約とプライバシーポリシーに同意したことになります。
        </p>
      </CardFooter>
    </Card>
  )
}
